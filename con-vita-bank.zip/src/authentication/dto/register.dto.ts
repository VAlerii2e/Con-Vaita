export class RegisterDto {
    email: string;
    name: string;
    password: string;
    phoneNumber:string;
  }
  
  export default RegisterDto;