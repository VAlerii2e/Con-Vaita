export class CreateBankAccountDto {}
