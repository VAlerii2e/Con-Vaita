import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { BankCardsService } from './bank-cards.service';
import { CreateBankCardDto } from './dto/create-bank-card.dto';
import { UpdateBankCardDto } from './dto/update-bank-card.dto';
import JwtAuthenticationGuard from '../authentication/jwt-authentication.guard';

@Controller('bank-cards')
export default class BankCardsController {
  constructor(
    private readonly bankCardsService: BankCardsService
  ) {}

  @Post()
  @UseGuards(JwtAuthenticationGuard)
  async createPost(@Body() post: CreateBankCardDto) {
    return this.bankCardsService.createBankCard(post);
  }

  @Post()
  create(@Body() createBankCardDto: CreateBankCardDto) {
    return this.bankCardsService.createBankCard(createBankCardDto);
  }



  @Get()
  findAll() {
    return this.bankCardsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.bankCardsService.getBankCardById(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateBankCardDto: UpdateBankCardDto) {
    return this.bankCardsService.updateBankCard(+id, updateBankCardDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.bankCardsService.remove(+id);
  }
}
