import { Module } from '@nestjs/common';
import { BankCardsService } from './bank-cards.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import BankCard from './entities/bank-card.entity';
import BankCardsController from './bank-cards.controller';

@Module({
  imports: [TypeOrmModule.forFeature([BankCard])],
  controllers: [BankCardsController],
  providers: [BankCardsService],
})
export class BankCardsModule {}
