export class CreateLoyalityCardDto {}
