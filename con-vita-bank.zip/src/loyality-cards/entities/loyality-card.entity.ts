import { User } from "../../users/entities/user.entity";
export class LoyalityCard 
{
    private id: number;
    private userId: number; 
    private expirationDate: string;
    private createdAt:string;
    private updatedAt:string;
    private owner:string

    
    constructor(id: number = 0, user:User, userId: number = 0, expirationDate: string = "", createdAt:string = "", updatedAt:string = "", owner:string = "")
    {
        this.id = id;
        this.userId = user.id;
        this.expirationDate = expirationDate;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.owner = owner;
    }
    get getLoyalityCardInfo():{ id: number, userId: number, expirationDate: string, createdAt: string,updatedAt:string, owner:string }
    {
      return {
        id:this.id,
          userId: this.userId,
          expirationDate:this.expirationDate,
          createdAt:this.createdAt,
          updatedAt:this.updatedAt,
          owner: this.owner
      };
    }
    
    
    addLoyalityCard(newLoyalityCard: LoyalityCard, loyalityCards: LoyalityCard[]): LoyalityCard[] {
        loyalityCards.push(newLoyalityCard);
      return loyalityCards;
  }


  deleteLoyalityCard(loyalityCardId: number, loyalityCards: LoyalityCard[]): LoyalityCard[] {
      return loyalityCards.filter(loyalityCard => loyalityCard.id !== loyalityCardId);
  }

  updateLoyalityCard(updatedLoyalityCard: LoyalityCard, loyalityCards: LoyalityCard[]): LoyalityCard[] {
      return loyalityCards.map( loyalityCard =>  loyalityCard.id === updatedLoyalityCard.id ? updatedLoyalityCard : loyalityCard);
  }   



}
