import { Injectable } from '@nestjs/common';
import { CreateLoyalityCardDto } from './dto/create-loyality-card.dto';
import { UpdateLoyalityCardDto } from './dto/update-loyality-card.dto';

@Injectable()
export class LoyalityCardsService {
  create(createLoyalityCardDto: CreateLoyalityCardDto) {
    return 'This action adds a new loyalityCard';
  }

  findAll() {
    return `This action returns all loyalityCards`;
  }

  findOne(id: number) {
    return `This action returns a #${id} loyalityCard`;
  }

  update(id: number, updateLoyalityCardDto: UpdateLoyalityCardDto) {
    return `This action updates a #${id} loyalityCard`;
  }

  remove(id: number) {
    return `This action removes a #${id} loyalityCard`;
  }
}
