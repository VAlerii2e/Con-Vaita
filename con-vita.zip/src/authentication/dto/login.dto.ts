export class LogInDto {
    email: string;
    password: string;
  }
  
  export default LogInDto;