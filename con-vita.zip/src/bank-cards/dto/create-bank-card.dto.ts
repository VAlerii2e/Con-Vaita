export class CreateBankCardDto {
    userId: number;
    name: string;   
    money: number; 
    owner: string; 
}
