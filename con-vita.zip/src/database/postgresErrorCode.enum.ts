enum PostgresErrorCode {
    UniqueViolation = '23505'
  }
  
  export default PostgresErrorCode;