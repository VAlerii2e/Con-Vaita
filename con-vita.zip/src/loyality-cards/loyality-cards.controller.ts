import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { LoyalityCardsService } from './loyality-cards.service';
import { CreateLoyalityCardDto } from './dto/create-loyality-card.dto';
import { UpdateLoyalityCardDto } from './dto/update-loyality-card.dto';

@Controller('loyality-cards')
export class LoyalityCardsController {
  constructor(private readonly loyalityCardsService: LoyalityCardsService) {}

  @Post()
  create(@Body() createLoyalityCardDto: CreateLoyalityCardDto) {
    return this.loyalityCardsService.create(createLoyalityCardDto);
  }

  @Get()
  findAll() {
    return this.loyalityCardsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.loyalityCardsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateLoyalityCardDto: UpdateLoyalityCardDto) {
    return this.loyalityCardsService.update(+id, updateLoyalityCardDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.loyalityCardsService.remove(+id);
  }
}
