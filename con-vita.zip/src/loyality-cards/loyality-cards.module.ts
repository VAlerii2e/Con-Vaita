import { Module } from '@nestjs/common';
import { LoyalityCardsService } from './loyality-cards.service';
import { LoyalityCardsController } from './loyality-cards.controller';

@Module({
  controllers: [LoyalityCardsController],
  providers: [LoyalityCardsService],
})
export class LoyalityCardsModule {}
