import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class User 
{
    @PrimaryGeneratedColumn()
    id?: number;

    @Column()
    public name: string;  

    @Column()
    public password: string;

    @Column()
    public email:string;
    
    @Column()
    public phoneNumber:string; 
}
export default User;